import http from "../http-common";
import ILocationData from "../types/location.type"

class LocationDataService {
  getAll(data: any) {
     return http.post<ILocationData>("/", data);
  }
  create(data: any) {
    return http.post<ILocationData>("/", data);
  }
  delete(data: any) {
    return http.post<ILocationData>("/", data);
  }
  edit(data: any) {
    return http.post<ILocationData>("/", data);
  }
}

export default new LocationDataService();