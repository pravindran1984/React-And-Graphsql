export default interface ILocationData {
    id?: any | null,
    location: string,
    picture: string
  }