import { Component, ChangeEvent } from "react";
import LocationDataService from "../services/location.service";
import { Link } from "react-router-dom";
import "../location.css";
import ILocationData from "../types/location.type";
declare var $: any;
type Props = {};

type State = {
  locations: Array<ILocationData>,
  location: string,
  picture: string,
  deleteId: number | null,
  addEditId: number | null
};

export default class Location extends Component<Props, State>{
  constructor(props: Props) {
    debugger;
    super(props);
    this.retrieveLocations = this.retrieveLocations.bind(this);
    this.onChangeLocation = this.onChangeLocation.bind(this);
    this.onChangePicture = this.onChangePicture.bind(this);
    this.saveLocations = this.saveLocations.bind(this);
    this.editLocations = this.editLocations.bind(this);
    this.deleteLocations = this.deleteLocations.bind(this);
    this.confirmDeleteLocations = this.confirmDeleteLocations.bind(this);
    this.addLocationPopup = this.addLocationPopup.bind(this);
    this.state = {
      locations: [],
      picture: "",
      location: "",
      deleteId: null,
      addEditId: null
    };
  }
  componentDidMount() {
    this.retrieveLocations();
  }
  addLocationPopup() {
    this.setState({
      location: "",
      picture: "",
      addEditId: null
    });
    $('#myModal').modal('show');
  }
  onChangeLocation(e: ChangeEvent<HTMLInputElement>) {
    this.setState({
      location: e.target.value
    });
  }

  onChangePicture(e: ChangeEvent<HTMLInputElement>) {
    this.setState({
      picture: e.target.value
    });
  }
  editLocations(location: any) {
    debugger;
    this.setState({
      location: location.location,
      picture: location.picture,
      addEditId: location.id
    });
    $('#myModal').modal('show');
  }
  deleteLocations(id: any) {
    $('#deleteModal').modal('show');
    this.setState({
      deleteId: id
    });

  }
  confirmDeleteLocations() {
    debugger;
    const id = this.state.deleteId;
    const requestData = {
      query: "mutation Mutation($deleteMessageId: Int!) {\n  deleteMessage(id: $deleteMessageId)\n}",
      variables: { deleteMessageId: id }
    }
    LocationDataService.delete(requestData)
      .then((response: any) => {
        if (response.data.data.deleteMessage === "Success") {
          this.retrieveLocations();
          $('#deleteModal').modal('hide');
        }
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }
  saveLocations() {
    const addEdit = this.state.addEditId;
    if (!addEdit) {
      const data: ILocationData = {
        id: null,
        location: this.state?.location || "",
        picture: this.state?.picture || ""
      };
      const requestData = {
        query: "mutation Post($location: String!, $picture: String!) {\n  post(location: $location, picture: $picture) {\n    location\n    picture\n  }\n}",
        variables: data
      }
      LocationDataService.create(requestData)
        .then((response: any) => {
          this.retrieveLocations();
          $('#myModal').modal('hide');
        })
        .catch((e: Error) => {
          console.log(e);
        });
    } else {
      const editdata = {
        editLocationId: addEdit,
        location: this.state?.location || "",
        picture: this.state?.picture || ""
      };
      const requestData = {
        query: "mutation EditLocation($editLocationId: Int!, $location: String!, $picture: String!) {\n  editLocation(id: $editLocationId, location: $location, picture: $picture) {\n    id\n    location\n    picture\n  }\n}",
        variables: editdata
      }
      LocationDataService.edit(requestData)
      .then((response: any) => {
        this.retrieveLocations();
        $('#myModal').modal('hide');
      })
      .catch((e: Error) => {
        console.log(e);
      });
    }

  }
  retrieveLocations() {
    LocationDataService.getAll({ "query": "query searchQuery {  searchLocations {    places {      location      picture      id    }  }}" })
      .then((response: any) => {
        this.setState({
          locations: response.data.data.searchLocations.places
        });
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  render() {
    const { locations, location, picture } = this.state;
    return (

      < div className="container content" >
        <div className="row"><div className="col"><button type="button" className="btn btn-success float-right" onClick={this.addLocationPopup}>Add Location</button></div></div><br /><div><div className="row gutters">{locations && locations.map((location: ILocationData, index: number) => (
          <div className="col-lg-4 col-md-4 col-sm-12">
            <div className="plan-card plan-one">
              <div className="pricing-header">
                <h4 className="plan-title">{location.location}</h4>
                <div className="plan-cost"><img width="300" height="200" src={location.picture}></img></div>
              </div>
              <div className="plan-footer">
                <button type="button" className="btn btn-info" onClick={() => this.editLocations(location)}>Edit</button>
                <button type="button" className="ml-lg-2 btn btn-danger" onClick={() => this.deleteLocations(location.id)}>Delete</button>
              </div>
            </div>
          </div>
        ))}</div></div >
        <div className="modal" id="myModal">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h4 className="modal-title">Add/Edit Location</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              <div className="modal-body">
                <div>
                  <div className="form-group">
                    <label htmlFor="title">Location</label>
                    <input
                      type="text"
                      className="form-control"
                      id="location"
                      required
                      value={location}
                      onChange={this.onChangeLocation}
                      name="location"
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="description">Picture Path</label>
                    <input
                      type="text"
                      className="form-control"
                      id="picture"
                      required
                      value={picture}
                      onChange={this.onChangePicture}
                      name="picture"
                    />
                  </div>


                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-success" onClick={this.saveLocations}>
                  Submit
                </button>
              </div>

            </div>
          </div>
        </div>
        <div className="modal" id="deleteModal">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h4 className="modal-title">Delete Location</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              <div className="modal-body">
                Are you sure want to delete?
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-info" onClick={() => this.confirmDeleteLocations()}>Confirm</button>
                <button type="button" className="btn btn-danger" data-dismiss="modal">No</button>
              </div>

            </div>
          </div>
        </div>
      </div>
    )
  }
}