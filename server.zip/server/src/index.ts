import { ApolloServer, gql } from 'apollo-server-express'
import { ApolloServerPluginDrainHttpServer } from 'apollo-server-core'
import express from 'express'
import http from 'http'
const _ = require("lodash");
const fs = require('fs');
const typeDefs = gql`
  type Query {
    searchLocations: SearchLocationsResult
  }

  type SearchLocationsResult {
    places: [Row!]!
  }

  type Row {
    id: Int!
    location: String!
    picture: String!
  }

  type Mutation {
    post(location: String!, picture: String!): Row!
    deleteMessage(id:Int!):String
    editLocation(id: Int!, location: String!, picture: String!): Row!
  }
`

const resolvers = {
  Query: {
    searchLocations() {
      let rawdata = fs.readFileSync('./src/data/location.json');
      let data = JSON.parse(rawdata);
      let places = _.orderBy(data.places, ['id'], ['desc']);
      return { places };
    },
  },
  Mutation: {
    post: (parent: any, args: any) => {
      let rawdata = fs.readFileSync('./src/data/location.json');
      let data = JSON.parse(rawdata);
      let idCount = data.places.length
      const location = {
        id: idCount + 1,
        location: args.location,
        picture: args.picture,
      }
      data.places.push(location)
      fs.writeFile("./src/data/location.json", JSON.stringify(data), function (err: any) {
        if (err) throw err;
        console.log('complete');
      }
      );
      return location;
    },
    deleteMessage: (parent: any, { id }: any) => {
      let rawdata = fs.readFileSync('./src/data/location.json');
      let data = JSON.parse(rawdata);
      let removedData = _.remove(data.places, (currentObject: any) => {
        return currentObject.id !== id;
      });
      fs.writeFile("./src/data/location.json", JSON.stringify({ places: removedData }), function (err: any) {
        if (err) throw err;
      });
      return "Success"
    },
    editLocation: (parent: any, args: any) => {
      let rawdata = fs.readFileSync('./src/data/location.json');
      let data = JSON.parse(rawdata);
      let removedData = _.remove(data.places, (currentObject: any) => {
        return currentObject.id !== args.id;
      });
      removedData.push({"id": args.id,"location": args.location,"picture": args.picture });
      console.log(removedData)
      fs.writeFile("./src/data/location.json", JSON.stringify({ places : removedData }), function (err: any) {
        if (err) throw err;
      }
      );
      return args;
    },
  },

}

async function listen(port: number) {
  const app = express()
  const httpServer = http.createServer(app)

  const server = new ApolloServer({
    typeDefs,
    resolvers,
    plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
  })
  await server.start()

  server.applyMiddleware({ app })

  return new Promise((resolve, reject) => {
    httpServer.listen(port).once('listening', resolve).once('error', reject)
  })
}

async function main() {
  try {
    await listen(8000)
    console.log('🚀 Server is ready at http://localhost:4000/graphql')
  } catch (err) {
    console.error('💀 Error starting the node server', err)
  }
}

void main()